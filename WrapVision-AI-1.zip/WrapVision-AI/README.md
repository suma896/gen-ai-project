# WrapVision AI: Sketch-to-Photorealistic Vehicle Wrap Renderer

GenAI end-term project. You give it a vehicle photo plus a wrap sketch, and it returns a
photorealistic wrap preview. The car's shape, camera angle, wheels, windows and background stay
unchanged.

**Stack:** SDXL + ControlNet Union + SDXL inpainting (🤗 Diffusers) · Grounding DINO + SAM 2.1
(🤗 Transformers) · OpenCV / Pillow / NumPy · Gradio · Google Colab (T4 GPU)

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the full pipeline, model licenses and
known limitations.

## Project status

| # | Milestone | Status |
|---|---|---|
| 1 | Environment setup & dependency check | ✅ code ready, needs a run on Colab |
| 2 | Vehicle image upload & preprocessing | ⏳ |
| 3 | Sketch upload & drawing editor | ⏳ |
| 4 | Vehicle segmentation & mask refinement | ⏳ |
| 5 | SDXL inpainting | ⏳ |
| 6 | ControlNet integration & sketch conditioning | ⏳ |
| 7 | Full image-to-image pipeline | ⏳ |
| 8 | Variations & post-processing | ⏳ |
| 9 | Gradio frontend | ⏳ |
| 10 | Testing, evaluation & optimisation | ⏳ |

Modules for future milestones contain only a docstring. Nothing in this repo simulates AI output.

## Structure

```
WrapVision-AI/
├── app.py                      # Gradio app            (Milestone 9)
├── requirements.txt
├── models/                     # segmentation, generation, controlnet_pipeline (M4–M6)
├── preprocessing/              # image, sketch, mask processing (M2–M4)
├── evaluation/                 # metrics + evaluation runner (M10)
├── utils/
│   ├── config.py               # model IDs, sizes, generation defaults, device helpers
│   └── env_check.py            # Milestone 1 environment checker
├── notebooks/00_colab_setup.ipynb
├── docs/ARCHITECTURE.md
├── tests/                      # pytest suites, one per milestone
├── assets/sample_inputs/       # your test photos & sketches
└── outputs/                    # generated images, reports (git-ignored)
```

## Setup

### Google Colab (recommended: needed for SDXL generation)
1. Push this folder to GitHub, or zip it.
2. Open `notebooks/00_colab_setup.ipynb` in Colab and select **Runtime → T4 GPU**.
3. Run all cells. The check must end with `0 critical failures`.

### Local (VS Code): for code editing, preprocessing, segmentation and tests
```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
# 1) torch: pick your build at https://pytorch.org/get-started/locally/
pip install torch torchvision         # CPU build, or the CUDA command from pytorch.org
# 2) everything else
pip install -r requirements.txt
python -m utils.env_check             # add --smoke-test if you have an NVIDIA GPU
python -m pytest -q
```

## Hardware

| Mode | Hardware | What runs |
|---|---|---|
| FULL_GPU | ≥15 GB VRAM (Colab T4, L4, A100, RTX 4080+) | Everything at ~1024 px |
| LOW_VRAM | 8–15 GB | Everything, slower (CPU offload) |
| CPU_ONLY | no NVIDIA GPU | Preprocessing, segmentation (slow), evaluation, UI dev |

## Licenses
Project code: MIT (or your choice). Model weights keep their own licenses. See
`docs/ARCHITECTURE.md`.
