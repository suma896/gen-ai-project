"""Shared utilities: configuration and environment checks."""
