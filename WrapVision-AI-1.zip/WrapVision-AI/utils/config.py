"""
Central configuration for WrapVision AI.

Every other module imports settings from here, so model IDs, image sizes and
generation defaults are changed in exactly one place.

This file deliberately does NOT import torch at module level, so it can be
imported on machines where torch is not installed yet (e.g. for unit tests or
when running the environment checker for the first time).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = PROJECT_ROOT / "outputs"
ASSETS_DIR = PROJECT_ROOT / "assets"
SAMPLE_INPUT_DIR = ASSETS_DIR / "sample_inputs"

# Hugging Face cache. On Colab, point HF_HOME at Google Drive so the ~15 GB of
# weights survive runtime restarts (see notebooks/00_colab_setup.ipynb).
HF_HOME = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface"))


# --------------------------------------------------------------------------- #
# Model registry
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ModelSpec:
    """Metadata for one pretrained model. Used by env_check to verify access."""

    repo_id: str
    role: str
    license: str           # as stated on the Hugging Face model card
    approx_size_gb: float  # download size of the files we actually load
    milestone: int         # first milestone that needs it
    required: bool = True  # False = optional / fallback


MODELS: dict[str, ModelSpec] = {
    # --- Generation (Milestones 5-8) ---------------------------------------
    "sdxl_base": ModelSpec(
        "stabilityai/stable-diffusion-xl-base-1.0",
        "SDXL base model used inside the ControlNet-inpainting pipeline",
        "CreativeML Open RAIL++-M", 7.0, 5),
    "sdxl_inpaint": ModelSpec(
        "diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
        "Dedicated SDXL inpainting UNet (baseline without ControlNet)",
        "CreativeML Open RAIL++-M", 5.2, 5),
    "vae_fp16_fix": ModelSpec(
        "madebyollin/sdxl-vae-fp16-fix",
        "SDXL VAE patched to run in float16 without NaNs/black images",
        "MIT", 0.33, 1),
    "controlnet_union": ModelSpec(
        "xinsir/controlnet-union-sdxl-1.0",
        "ControlNet++ Union (one model: depth, canny, lineart, ...)",
        "Apache-2.0", 2.5, 6),
    "controlnet_depth": ModelSpec(
        "diffusers/controlnet-depth-sdxl-1.0",
        "Fallback single-purpose depth ControlNet",
        "CreativeML Open RAIL++-M", 2.5, 6, required=False),
    "controlnet_canny": ModelSpec(
        "diffusers/controlnet-canny-sdxl-1.0",
        "Fallback single-purpose canny-edge ControlNet",
        "CreativeML Open RAIL++-M", 2.5, 6, required=False),
    # --- Perception (Milestones 4, 6) --------------------------------------
    "grounding_dino": ModelSpec(
        "IDEA-Research/grounding-dino-tiny",
        "Text-prompted detector: finds 'car', 'window', 'wheel' boxes",
        "Apache-2.0", 0.7, 4),
    "sam2": ModelSpec(
        "facebook/sam2.1-hiera-base-plus",
        "SAM 2.1 segmenter: turns detector boxes into pixel masks",
        "Apache-2.0", 0.32, 4),
    "sam2_tiny": ModelSpec(
        "facebook/sam2.1-hiera-tiny",
        "Smaller SAM 2.1 for CPU / low-VRAM machines",
        "Apache-2.0", 0.16, 4, required=False),
    "depth": ModelSpec(
        "depth-anything/Depth-Anything-V2-Small-hf",
        "Monocular depth estimator -> depth map for ControlNet",
        "Apache-2.0", 0.1, 6),
    # --- Evaluation (Milestone 10) -----------------------------------------
    "clip": ModelSpec(
        "openai/clip-vit-large-patch14",
        "CLIP image-text similarity for evaluation",
        "MIT", 1.7, 10, required=False),
}


# --------------------------------------------------------------------------- #
# Image settings
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ImageConfig:
    allowed_extensions: tuple[str, ...] = (".jpg", ".jpeg", ".png")
    max_upload_mb: int = 20
    # SDXL was trained around 1024x1024 (~1 megapixel). We keep the photo's
    # aspect ratio and pick a size whose sides are multiples of 8 (VAE stride)
    # and whose area is close to this target.
    target_pixels: int = 1024 * 1024
    size_multiple: int = 8
    min_side: int = 512
    max_side: int = 1536


# --------------------------------------------------------------------------- #
# Generation defaults (tuned in Milestones 5-8)
# --------------------------------------------------------------------------- #
@dataclass
class GenerationConfig:
    num_inference_steps: int = 30
    guidance_scale: float = 6.0
    # strength < 1 keeps part of the colour-composited init image, which is
    # how the sketch's colours survive generation (see docs/ARCHITECTURE.md).
    strength: float = 0.55
    controlnet_scale_depth: float = 0.6
    controlnet_scale_edges: float = 0.4
    num_variations: int = 3
    base_seed: int = 42
    mask_feather_px: int = 9
    negative_prompt: str = (
        "deformed car, distorted wheels, melted body, extra wheels, blurry, "
        "low quality, cartoon, text, watermark, logo"
    )
    prompt_suffix: str = (
        "professional automotive photography, glossy vinyl car wrap, "
        "realistic reflections, sharp details, high quality"
    )


# --------------------------------------------------------------------------- #
# Hardware thresholds used to choose a run mode
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class HardwareConfig:
    full_gpu_min_vram_gb: float = 15.0   # e.g. Colab T4 (15 GB usable), L4, A100
    low_vram_min_gb: float = 8.0         # works with CPU offload, slower
    min_free_disk_gb: float = 25.0       # weights + outputs
    min_ram_gb: float = 12.0


IMAGE = ImageConfig()
GENERATION = GenerationConfig()
HARDWARE = HardwareConfig()


# --------------------------------------------------------------------------- #
# Device helpers (torch imported lazily)
# --------------------------------------------------------------------------- #
def get_device() -> str:
    """Return 'cuda', 'mps' or 'cpu' depending on what is available."""
    try:
        import torch
    except ImportError:
        return "cpu"
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def get_dtype(device: str | None = None):
    """float16 on GPU (halves memory), float32 on CPU (fp16 is slow/unsupported there)."""
    import torch

    device = device or get_device()
    return torch.float16 if device in ("cuda", "mps") else torch.float32


def ensure_dirs() -> None:
    for d in (OUTPUT_DIR, SAMPLE_INPUT_DIR):
        d.mkdir(parents=True, exist_ok=True)
