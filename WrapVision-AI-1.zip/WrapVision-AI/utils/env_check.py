"""
Milestone 1 - environment checker.

Run from the project root:

    python -m utils.env_check                 # packages, hardware, model access
    python -m utils.env_check --smoke-test    # + real GPU test with the SDXL VAE
    python -m utils.env_check --skip-network  # offline: no Hugging Face calls

What it verifies
  1. Python version and every required package (import + version).
  2. PyTorch device: CUDA GPU name, VRAM, fp16 matrix-multiply test.
  3. System RAM and free disk space for the model cache.
  4. Hugging Face Hub: each model in utils.config.MODELS exists, is reachable,
     and whether it is gated; prints the license from the model card.
  5. (--smoke-test) Downloads the 330 MB SDXL VAE, encodes and decodes a
     procedurally generated test image on the GPU and reports reconstruction
     PSNR. This proves diffusers + weights download + GPU inference all work
     end-to-end. It is a VAE round trip, not wrap generation.

The script writes outputs/env_report.json and exits with code 1 if anything
critical failed.
"""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata as md
import json
import platform
import shutil
import sys
import time
from dataclasses import dataclass, field, asdict

from utils.config import HARDWARE, HF_HOME, MODELS, OUTPUT_DIR, ensure_dirs

# (pip name, import name, minimum version, critical?)
REQUIRED_PACKAGES = [
    ("torch", "torch", "2.4", True),
    ("torchvision", "torchvision", "0.19", True),
    ("diffusers", "diffusers", "0.43", True),
    ("transformers", "transformers", "5.0", True),
    ("accelerate", "accelerate", "1.0", True),
    ("safetensors", "safetensors", "0.4", True),
    ("huggingface_hub", "huggingface_hub", "0.30", True),
    ("numpy", "numpy", "1.26", True),
    ("pillow", "PIL", "10.0", True),
    ("opencv-python-headless", "cv2", "4.9", True),
    ("scikit-image", "skimage", "0.22", True),
    ("gradio", "gradio", "5.0", False),        # needed from Milestone 3
    ("matplotlib", "matplotlib", "3.8", False),  # needed in Milestone 10
    ("pandas", "pandas", "2.0", False),
    ("psutil", "psutil", "5.9", False),
]


@dataclass
class Check:
    name: str
    ok: bool
    detail: str
    critical: bool = True


@dataclass
class Report:
    checks: list[Check] = field(default_factory=list)
    info: dict = field(default_factory=dict)

    def add(self, name, ok, detail, critical=True):
        self.checks.append(Check(name, ok, detail, critical))
        mark = "PASS" if ok else ("FAIL" if critical else "WARN")
        print(f"  [{mark}] {name}: {detail}")

    @property
    def critical_failures(self):
        return [c for c in self.checks if not c.ok and c.critical]


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _version_tuple(v: str) -> tuple:
    out = []
    for part in v.split("+")[0].split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        if num == "":
            break
        out.append(int(num))
    return tuple(out)


def version_at_least(installed: str, minimum: str) -> bool:
    return _version_tuple(installed) >= _version_tuple(minimum)


def classify_hardware(device: str, vram_gb: float) -> str:
    """Map hardware to the run mode the rest of the project will use."""
    if device != "cuda":
        return "CPU_ONLY"
    if vram_gb >= HARDWARE.full_gpu_min_vram_gb:
        return "FULL_GPU"
    if vram_gb >= HARDWARE.low_vram_min_gb:
        return "LOW_VRAM"
    return "INSUFFICIENT_GPU"


MODE_ADVICE = {
    "FULL_GPU": "SDXL + ControlNet at ~1024 px with model CPU offload. Recommended.",
    "LOW_VRAM": "SDXL will run with sequential CPU offload / smaller resolution; expect slow generation.",
    "INSUFFICIENT_GPU": "GPU too small for SDXL. Use Google Colab (T4) for generation.",
    "CPU_ONLY": ("Pre-processing, segmentation and evaluation can run here, but SDXL "
                 "generation on CPU takes many minutes per image. Use Colab for Milestones 5-8."),
}


# --------------------------------------------------------------------------- #
# Individual checks
# --------------------------------------------------------------------------- #
def check_python(r: Report):
    print("\n1. Python")
    v = sys.version_info
    r.info["python"] = platform.python_version()
    r.add("Python version", v >= (3, 10), f"{platform.python_version()} (need >= 3.10)")


def check_packages(r: Report):
    print("\n2. Packages")
    versions = {}
    for pip_name, import_name, minimum, critical in REQUIRED_PACKAGES:
        try:
            installed = md.version(pip_name)
        except md.PackageNotFoundError:
            installed = None
        if installed is None:
            r.add(pip_name, False, "not installed", critical)
            continue
        try:
            importlib.import_module(import_name)
            imported = True
            err = ""
        except Exception as e:  # import can fail even when installed (ABI clash)
            imported, err = False, f"{type(e).__name__}: {e}"
        versions[pip_name] = installed
        ok = imported and version_at_least(installed, minimum)
        detail = f"{installed} (need >= {minimum})" + (f" IMPORT ERROR {err}" if not imported else "")
        r.add(pip_name, ok, detail, critical)
    r.info["packages"] = versions

    # The specific classes later milestones depend on
    print("\n   Required pipeline / model classes")
    needed = {
        "diffusers": ["StableDiffusionXLInpaintPipeline",
                      "StableDiffusionXLControlNetInpaintPipeline",
                      "StableDiffusionXLControlNetUnionInpaintPipeline",
                      "ControlNetModel", "ControlNetUnionModel", "AutoencoderKL"],
        "transformers": ["Sam2Model", "Sam2Processor",
                         "AutoModelForZeroShotObjectDetection",
                         "AutoModelForDepthEstimation", "CLIPModel"],
    }
    for mod_name, classes in needed.items():
        try:
            mod = importlib.import_module(mod_name)
        except Exception:
            r.add(f"{mod_name} classes", False, "module not importable")
            continue
        missing = [c for c in classes if not hasattr(mod, c)]
        r.add(f"{mod_name} classes", not missing,
              "all present" if not missing else f"missing: {', '.join(missing)}")


def check_torch(r: Report) -> tuple[str, float]:
    print("\n3. PyTorch / GPU")
    try:
        import torch
    except Exception as e:
        r.add("torch import", False, str(e))
        return "cpu", 0.0

    r.info["torch"] = torch.__version__
    r.info["torch_cuda_build"] = torch.version.cuda
    device, vram_gb = "cpu", 0.0

    if torch.cuda.is_available():
        device = "cuda"
        props = torch.cuda.get_device_properties(0)
        vram_gb = props.total_memory / 1024**3
        r.info.update(gpu=props.name, vram_gb=round(vram_gb, 2),
                      compute_capability=f"{props.major}.{props.minor}",
                      bf16_supported=torch.cuda.is_bf16_supported())
        r.add("CUDA GPU", True, f"{props.name}, {vram_gb:.1f} GB VRAM, "
                                f"compute {props.major}.{props.minor}, CUDA {torch.version.cuda}")
        try:
            a = torch.randn(2048, 2048, device="cuda", dtype=torch.float16)
            torch.cuda.synchronize()
            t0 = time.time()
            for _ in range(10):
                b = a @ a
            torch.cuda.synchronize()
            dt = (time.time() - t0) / 10
            tflops = 2 * 2048**3 / dt / 1e12
            finite = bool(torch.isfinite(b).all())
            r.add("fp16 matmul", finite, f"{tflops:.1f} TFLOPS, finite={finite}")
            del a, b
            torch.cuda.empty_cache()
        except Exception as e:
            r.add("fp16 matmul", False, f"{type(e).__name__}: {e}")
    else:
        r.add("CUDA GPU", False, "no CUDA GPU detected", critical=False)

    mode = classify_hardware(device, vram_gb)
    r.info["run_mode"] = mode
    print(f"   Run mode: {mode} -> {MODE_ADVICE[mode]}")
    return device, vram_gb


def check_system(r: Report):
    print("\n4. System resources")
    try:
        import psutil
        ram = psutil.virtual_memory().total / 1024**3
        r.info["ram_gb"] = round(ram, 1)
        r.add("System RAM", ram >= HARDWARE.min_ram_gb,
              f"{ram:.1f} GB (recommend >= {HARDWARE.min_ram_gb:.0f} GB to load SDXL)",
              critical=False)
    except ImportError:
        r.add("System RAM", False, "psutil not installed, skipped", critical=False)

    HF_HOME.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(HF_HOME).free / 1024**3
    need = sum(m.approx_size_gb for m in MODELS.values() if m.required)
    r.info.update(hf_home=str(HF_HOME), free_disk_gb=round(free, 1))
    r.add("Disk space (HF cache)", free >= HARDWARE.min_free_disk_gb,
          f"{free:.1f} GB free at {HF_HOME} (required models ~{need:.0f} GB)",
          critical=False)


def check_models(r: Report):
    print("\n5. Hugging Face model access")
    try:
        from huggingface_hub import HfApi
    except ImportError:
        r.add("huggingface_hub", False, "not installed")
        return
    api = HfApi()
    results = {}
    for key, spec in MODELS.items():
        try:
            info = api.model_info(spec.repo_id)
            card = info.card_data.to_dict() if info.card_data else {}
            hub_license = card.get("license", "unknown")
            gated = info.gated
            ok = not gated
            detail = f"{spec.repo_id} | license={hub_license} | gated={gated} | M{spec.milestone}"
            if gated:
                detail += " -> accept terms on the model page and run `hf auth login`"
            results[key] = {"repo": spec.repo_id, "license": hub_license, "gated": gated}
        except Exception as e:
            ok, detail = False, f"{spec.repo_id} | {type(e).__name__}: {str(e)[:120]}"
            results[key] = {"repo": spec.repo_id, "error": str(e)[:200]}
        r.add(key, ok, detail, critical=spec.required)
    r.info["models"] = results


def smoke_test_vae(r: Report, device: str):
    """Encode -> decode a synthetic image with the SDXL VAE (real GPU inference)."""
    print("\n6. Smoke test: SDXL VAE round trip")
    try:
        import numpy as np
        import torch
        from diffusers import AutoencoderKL
        from PIL import Image
        from skimage.metrics import peak_signal_noise_ratio

        from utils.config import get_dtype

        dtype = get_dtype(device)
        t0 = time.time()
        vae = AutoencoderKL.from_pretrained(MODELS["vae_fp16_fix"].repo_id, torch_dtype=dtype).to(device)
        load_s = time.time() - t0

        # Procedural test pattern (gradients + shapes) - just something with
        # edges and colours for the VAE to reconstruct.
        h = w = 512
        yy, xx = np.mgrid[0:h, 0:w]
        img = np.stack([xx / w, yy / h, 0.5 + 0.5 * np.sin(xx / 25.0)], -1)
        img[(xx - 256) ** 2 + (yy - 256) ** 2 < 90**2] = [0.9, 0.1, 0.1]
        img[100:140, 50:460] = [0.05, 0.05, 0.05]
        img = (img * 255).astype(np.uint8)

        x = torch.from_numpy(img).permute(2, 0, 1)[None].to(device, dtype) / 127.5 - 1
        t0 = time.time()
        with torch.no_grad():
            latents = vae.encode(x).latent_dist.sample() * vae.config.scaling_factor
            recon = vae.decode(latents / vae.config.scaling_factor).sample
        if device == "cuda":
            torch.cuda.synchronize()
        infer_s = time.time() - t0

        out = ((recon[0].float().clamp(-1, 1) + 1) * 127.5).permute(1, 2, 0).cpu().numpy().astype(np.uint8)
        psnr = peak_signal_noise_ratio(img, out)
        Image.fromarray(np.concatenate([img, out], 1)).save(OUTPUT_DIR / "milestone1_vae_roundtrip.png")

        ok = bool(np.isfinite(out).all()) and psnr > 20
        r.info["smoke_test"] = {"latent_shape": list(latents.shape), "psnr_db": round(float(psnr), 2),
                                "load_s": round(load_s, 1), "inference_s": round(infer_s, 2)}
        r.add("VAE round trip", ok,
              f"latent {tuple(latents.shape)}, PSNR {psnr:.1f} dB, load {load_s:.0f}s, "
              f"infer {infer_s:.2f}s -> outputs/milestone1_vae_roundtrip.png")
        if device == "cuda":
            r.info["smoke_test"]["peak_vram_gb"] = round(torch.cuda.max_memory_allocated() / 1024**3, 2)
    except Exception as e:
        r.add("VAE round trip", False, f"{type(e).__name__}: {e}")


# --------------------------------------------------------------------------- #
def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="WrapVision AI environment check (Milestone 1)")
    p.add_argument("--smoke-test", action="store_true", help="download SDXL VAE and run it")
    p.add_argument("--skip-network", action="store_true", help="skip Hugging Face checks")
    args = p.parse_args(argv)

    ensure_dirs()
    r = Report()
    print("=" * 70 + "\nWrapVision AI - environment check\n" + "=" * 70)
    check_python(r)
    check_packages(r)
    device, _ = check_torch(r)
    check_system(r)
    if not args.skip_network:
        check_models(r)
    if args.smoke_test:
        smoke_test_vae(r, device)

    report_path = OUTPUT_DIR / "env_report.json"
    report_path.write_text(json.dumps(
        {"checks": [asdict(c) for c in r.checks], "info": r.info}, indent=2, default=str))

    fails = r.critical_failures
    warns = [c for c in r.checks if not c.ok and not c.critical]
    print("\n" + "=" * 70)
    print(f"Result: {len(r.checks) - len(fails) - len(warns)} passed, "
          f"{len(warns)} warnings, {len(fails)} critical failures")
    print(f"Run mode: {r.info.get('run_mode', 'unknown')}")
    print(f"Report: {report_path}")
    if fails:
        print("Fix these before Milestone 2:")
        for c in fails:
            print(f"  - {c.name}: {c.detail}")
    print("=" * 70)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
