"""Milestone 1 tests. Run: pytest -q"""
from utils import config
from utils.env_check import classify_hardware, version_at_least, main


def test_version_compare():
    assert version_at_least("0.43.0", "0.43")
    assert version_at_least("2.15.0+cu126", "2.4")
    assert not version_at_least("4.57.1", "5.0")
    assert version_at_least("5.23.0.dev0", "5.0")


def test_hardware_modes():
    assert classify_hardware("cpu", 0) == "CPU_ONLY"
    assert classify_hardware("cuda", 15.8) == "FULL_GPU"      # Colab T4
    assert classify_hardware("cuda", 12.0) == "LOW_VRAM"
    assert classify_hardware("cuda", 4.0) == "INSUFFICIENT_GPU"


def test_model_registry_is_complete():
    for key in ["sdxl_base", "vae_fp16_fix", "controlnet_union", "grounding_dino", "sam2", "depth"]:
        spec = config.MODELS[key]
        assert "/" in spec.repo_id and spec.license and spec.approx_size_gb > 0


def test_generation_defaults_sane():
    g = config.GENERATION
    assert 0 < g.strength < 1          # must keep part of the init image
    assert 1 <= g.num_variations <= 3


def test_env_check_runs_offline():
    # Exit code 0 or 1 depending on the machine, but it must not crash
    assert main(["--skip-network"]) in (0, 1)
    assert (config.OUTPUT_DIR / "env_report.json").exists()
