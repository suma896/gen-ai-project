"""Evaluation (Milestone 10): masked SSIM/PSNR, IoU, CLIP score, human study."""
