# WrapVision AI: Architecture

## The core problem

The goal is to change only the body paint, follow a coloured sketch, and keep everything else
exactly as it was. Out of the box, no pretrained model does all three:

| Tool | What it's good at | What it can't do alone |
|---|---|---|
| SDXL inpainting | Repaints a masked region realistically | Ignores the sketch, since it only reads the text prompt |
| ControlNet (depth / canny / lineart) | Keeps shapes and edges | **Ignores colour.** A canny edge map of a red/black stripe is just white lines on black |
| Text prompt | Describes material and style | Can't say exactly where a stripe goes |

The sketch therefore has to reach the model through three routes at the same time.

## Final pipeline

```
Vehicle photo ─┬─► [1] Preprocess (validate, resize to ~1 MP, multiples of 8)
               │
               ├─► [2] Segmentation
               │      Grounding DINO "car" box ─► SAM 2.1 ─► car mask
               │      Grounding DINO "window . wheel . headlight . license plate"
               │                              ─► SAM 2.1 ─► protected masks
               │      body mask = car − protected, then morphology clean-up + feather
               │
Wrap sketch ───┼─► [3] Sketch processing
(upload or     │      align to photo · extract colour layer · dominant colours (k-means)
 drawn on the  │      edge map of design boundaries
 photo)        │
               ├─► [4a] COLOUR route: "colour composite" init image
               │      inside body mask: L channel from photo (keeps shading)
               │                        a,b channels from sketch (gives the colours)
               │
               ├─► [4b] STRUCTURE route: ControlNet Union
               │      depth map of photo (Depth Anything V2) ─► keeps body shape
               │      canny of photo edges + sketch boundaries ─► keeps panel lines & stripe edges
               │
               ├─► [4c] TEXT route: user description + "glossy vinyl wrap, automotive photography"
               │
               └─► [4] SDXL ControlNet-Inpaint pipeline
                      image = colour composite, mask = body mask,
                      strength ≈ 0.45–0.65   (re-renders reflections/gloss but keeps layout)
                      3 seeds ─► 3 variations
                          │
                          ▼
                  [5] Post-process: paste protected pixels back from the original
                      with a feathered mask, so wheels, windows and background are pixel-identical
                          │
                          ▼
                  [6] Gradio UI: before/after, gallery, download
```

### Why `strength` is the key setting
Inpainting with `strength=s` adds noise equal to fraction *s* of the diffusion schedule to the init
image and then denoises it. At `s≈1` the colour composite is wiped out and the model invents
its own paint job. At `s≈0.3` it barely changes anything, so the result looks like a flat sticker.
Around 0.5 it keeps the low-frequency information (colour layout) and regenerates the high-frequency
information (reflections, clear-coat highlights, panel-gap shadows). Milestone 7 sweeps this value
and reports the result.

## Models and licenses (verified from Hugging Face model cards, Nov 2026)

| Role | Model | License | Size |
|---|---|---|---|
| Base diffusion model | `stabilityai/stable-diffusion-xl-base-1.0` | CreativeML Open RAIL++-M | ~7 GB fp16 |
| Inpainting baseline | `diffusers/stable-diffusion-xl-1.0-inpainting-0.1` | CreativeML Open RAIL++-M | ~5 GB fp16 |
| fp16-safe VAE | `madebyollin/sdxl-vae-fp16-fix` | MIT | 0.3 GB |
| ControlNet (primary) | `xinsir/controlnet-union-sdxl-1.0` (ProMax) | Apache-2.0 | 2.5 GB |
| ControlNet (fallback) | `diffusers/controlnet-depth-sdxl-1.0`, `…-canny-sdxl-1.0` | Open RAIL++-M | 2.5 GB each |
| Text-prompted detector | `IDEA-Research/grounding-dino-tiny` | Apache-2.0 | 0.7 GB |
| Segmentation | `facebook/sam2.1-hiera-base-plus` (tiny for CPU) | Apache-2.0 | 0.3 GB |
| Depth | `depth-anything/Depth-Anything-V2-Small-hf` | Apache-2.0 | 0.1 GB (note: the Base/Large variants are non-commercial) |
| Evaluation | `openai/clip-vit-large-patch14` | MIT | 1.7 GB |

None of these models are gated. The Open RAIL++-M license allows commercial use but includes
use-based restrictions, which is fine for an academic project. Cite it in the report.

SAM 2.1 and Grounding DINO are loaded through **🤗 Transformers** (`Sam2Model`,
`AutoModelForZeroShotObjectDetection`), not the original `sam2` GitHub package. That avoids
compiling CUDA extensions on Colab.

## Known limitations

1. **The viewpoint has to match.** A side-view sketch can't be mapped onto a 3/4-view photo
   without a 3D car model. The recommended workflow is drawing directly over the photo in the
   editor, which gives perfect alignment. Uploaded sketches must use the same viewpoint as the photo.
2. **Fine detail.** SDXL works in a latent space 8× smaller than the image, so thin pinstripes
   (<8 px) and text or logos will blur or change. The post-processing step can optionally overlay
   sharp sketch edges.
3. **Exact colour match** is approximate. Diffusion shifts hues slightly; Milestone 8 adds an optional
   colour-correction pass towards the sketch palette.
4. **Speed.** About 40–90 s per 1024 px image on a free Colab T4 (estimate; measured in Milestone 5).
