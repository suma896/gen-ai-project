"""Model wrappers.

segmentation.py         -> Milestone 4 (Grounding DINO + SAM 2.1 body-panel masks)
generation.py           -> Milestone 5 (SDXL inpainting)
controlnet_pipeline.py  -> Milestone 6 (ControlNet conditioning)

These modules are created in their milestones; nothing here is implemented yet.
"""
