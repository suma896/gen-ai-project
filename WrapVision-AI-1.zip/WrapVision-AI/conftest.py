# Makes the project root importable for pytest (e.g. `from utils import config`).
