"""Pre-processing.

image_processing.py   -> Milestone 2 (validation, resizing to SDXL-friendly sizes)
sketch_processing.py  -> Milestone 3 (sketch alignment, colour extraction, edge maps)
mask_processing.py    -> Milestone 4 (mask refinement, feathering)
"""
